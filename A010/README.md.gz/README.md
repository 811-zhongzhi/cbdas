# Clustering beta-lactamase designs, looking at predicted activity under additivity vs observed, and distance of designs to nearest evotuning set members.

1. 001_BLAC_heatmap_clusters_additivity_dist_to_wt_and_ET_set - Does all of the above. Generates Figs 2c-e.