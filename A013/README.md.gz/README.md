# Explore potential evolutionary and structural explanations for why low-N design works

Supp Figs 14, 15, and 16.

1. 001_gfp_structural_mutation_stats and 002_gfp_structure_stats - do the above for GFP
2. 003_blac_structural_mutation_stats and 004_blac_structure_stats - do the above for beta-lactamase
