# Compare sequence designs to low-N training mutants and evotuning sequences

1. 001_generate_seq_dist_hist_plots_and_create_ET_ablation_sets - Looks at Levenshtein distances of wild-type sequences to evotuning sequence set members. Makes plots for Supp Fig 7.
2. 002_aln_seqs_and_compute_similarity_train_and_et_sets - Compares sequence designs to low-N training sequences and evotuning sequences. Makes plots used in Supp Figs 8 and 12.